
console.log("JavaScript is working!");
document.addEventListener('DOMContentLoaded', (event) => {
  const tabs = document.querySelectorAll('#navTabs li a');

  tabs.forEach(tab => {
      tab.addEventListener('mouseover', () => {
          tab.style.color = 'blue'; // Change this color to your preferred hover color
          tab.style.textDecoration = 'underline'; // Add underline on hover
          tab.style.fontSize = 'larger'; // Increase size on hover
      });

      tab.addEventListener('mouseout', () => {
          tab.style.color = ''; // Revert to the original color
          tab.style.textDecoration = 'none'; // Remove underline on mouse out
          tab.style.fontSize = ''; // Revert to the original size
      });
  });
});
